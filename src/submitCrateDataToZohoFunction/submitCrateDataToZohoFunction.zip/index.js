// Example AWS Lambda function for submitting crate data to Zoho
// This would be deployed as a separate Lambda function

const { createClient } = require('@supabase/supabase-js');

// Initialize Supabase client
const supabaseUrl = process.env.SUPABASE_URL;
const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
const supabase = createClient(supabaseUrl, supabaseServiceKey);

// Helper function to validate JWT token (in production, use a proper JWT library)
const validateToken = (token) => {
  try {
    const decoded = Buffer.from(token, 'base64').toString();
    const [userId, timestamp] = decoded.split(':');
    // Check if token is expired (24 hour validity for this example)
    const expirationTime = parseInt(timestamp) + 24 * 60 * 60 * 1000;
    if (Date.now() > expirationTime) {
      return null;
    }
    return userId;
  } catch (error) {
    return null;
  }
};

exports.handler = async (event) => {
  try {
    // Check authentication
    const authHeader = event.headers.Authorization || event.headers.authorization;
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return {
        statusCode: 401,
        body: JSON.stringify({
          success: false,
          error: 'Authorization required'
        }),
        headers: {
          'Content-Type': 'application/json',
          'Access-Control-Allow-Origin': '*'
        }
      };
    }
    const token = authHeader.split(' ')[1];
    const userId = validateToken(token);
    if (!userId) {
      return {
        statusCode: 401,
        body: JSON.stringify({
          success: false,
          error: 'Invalid or expired token'
        }),
        headers: {
          'Content-Type': 'application/json',
          'Access-Control-Allow-Origin': '*'
        }
      };
    }
    // ...rest of your submit crate data to Zoho logic...
  } catch (error) {
    return {
      statusCode: 500,
      body: JSON.stringify({ success: false, error: 'Internal server error' }),
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*'
      }
    };
  }
};
